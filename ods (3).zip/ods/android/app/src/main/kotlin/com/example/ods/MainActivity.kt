package com.example.ods

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
