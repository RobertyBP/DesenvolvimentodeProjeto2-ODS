import 'package:flutter/material.dart';
import 'package:ods/screens/home.dart';
import '../services/auth_service.dart';
class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final _formKey = GlobalKey<FormState>();
  String _senha = '';
  String _nome = '';
  String _email = '';
  AuthService authService = AuthService();

  Future<void> _registrar() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      authService.registrar(_email, _senha, _nome);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Cadastro realizado!"),
      ));
      Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Home()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Cadastro")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(
                  labelText: "Nome Completo",
                  icon:Icon(Icons.person)),
                validator: (value) => value!.isEmpty ? "Informe um nome válido" : null,
                onSaved: (value) => _nome = value!,
              ),
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Email",
                  icon: Icon(Icons.person)),
                validator: (value) => value!.contains("@") ? null : "Email inválido",
                onSaved: (value) => _email = value!,
              ),
              
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Senha",
                  icon: Icon(Icons.password)),
                obscureText: true,
                validator: (value) => value!.length >= 6 ? null : "Senha curta",
                onSaved: (value) => _senha = value!,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _registrar,
                child: Text("Registrar"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}