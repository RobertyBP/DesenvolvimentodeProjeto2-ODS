import 'package:flutter/material.dart';
import 'package:ods/screens/register.dart';
import 'package:ods/screens/home.dart';
import 'package:ods/services/auth_provider.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  
  String _email = '';
  String _senha = '';
  AuthService authService = AuthService();

  // Redireciona para a página de cadastro
  void _loginC() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Register()),
    );
  }

  // Realiza login e verifica autenticação
  void _login() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      try {
  bool isUserRegistered = await authService.verificarCadastro(_email);
  if (!isUserRegistered) {
    throw Exception("Usuário não encontrado!");
  }

  bool isAuthenticated = await authService.login(_email, _senha);
  if (!isAuthenticated) {
    throw Exception("Senha incorreta!");
  }

  String? nome = await authService.obterNome(_email);
  print("Nome do usuário: $nome");

  Provider.of<AuthProvider>(context, listen: false).login();
  Navigator.pushReplacement(
    context,
    MaterialPageRoute(builder: (context) => Home()),
  );
}catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Erro ao autenticar. Tente novamente.")),
        );
        print("Erro de login: $e");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Campo de Email
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Email",
                  icon: Icon(Icons.person),
                ),
                validator: (value) => value!.contains("@") ? null : "Email inválido",
                onSaved: (value) => _email = value!,
              ),
              
              // Campo de Senha
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Senha",
                  icon: Icon(Icons.password),
                ),
                obscureText: true,
                validator: (value) => value!.length >= 6 ? null : "Senha curta",
                onSaved: (value) => _senha = value!,
              ),

              SizedBox(height: 20),

              // Botão de Login
              ElevatedButton(
                onPressed: _login,
                child: Text("Login"),
              ),

              SizedBox(height: 20),

              // Botão de Cadastro
              ElevatedButton(
                onPressed: _loginC,
                child: Text("Criar conta"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}