import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final CollectionReference usuarios =
      FirebaseFirestore.instance.collection("usuarios");

  // Verificar se o usuário está cadastrado
  Future<bool> verificarCadastro(String email) async {
    DocumentSnapshot doc = await usuarios.doc(email).get();
    return doc.exists;
  }

  // Realizar login (validando senha)
  Future<bool> login(String email, String senha) async {
    DocumentSnapshot doc = await usuarios.doc(email).get();
    if (doc.exists) {
      String senhaBanco = doc.get("senha");
      return senhaBanco == senha;
    }
    return false;
  }

  // Registrar usuário no Firebase
  Future<void> registrar(String email, String senha, String nome) async {
    await usuarios.doc(email).set({
      "nome": nome,
      "senha": senha, // Em produção, use criptografia!
    });
    print("Usuário registrado!");
  }

  // Obter nome do usuário
  Future<String?> obterNome(String email) async {
    DocumentSnapshot doc = await usuarios.doc(email).get();
    if (doc.exists) {
      return doc.get("nome");
    }
    return null;
  }
}