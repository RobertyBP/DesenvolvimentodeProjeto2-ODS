class AuthService {
  Map<String, Map<String, String>> _usuarios = {
    "email@email.com": {
      "nome": "adm",
      "senha": "senha135",
    },
  };

  bool verificarCadastro(String email) {
    return _usuarios.containsKey(email);
  }

  bool login(String email, String senha) {
    return _usuarios[email]?["senha"] == senha;
  }

  void registrar(String email, String senha, String nome) {
    _usuarios[email] = {"nome": nome, "senha": senha};
  }

  String? obterNome(String email) {
    return _usuarios[email]?["nome"];
  }
}