import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  bool _isLoggedIn = false;

  bool get isLoggedIn => _isLoggedIn;

  void login() {
    _isLoggedIn = true;
    notifyListeners(); // Notifica widgets para atualizar
  }

  void logout() {
    _isLoggedIn = false;
    notifyListeners(); // Notifica widgets para atualizar
  }
}