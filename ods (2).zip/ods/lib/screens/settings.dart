import 'package:flutter/material.dart';
import 'package:ods/services/auth_provider.dart';
import 'package:provider/provider.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {

  bool isDarkTheme = false;
  String selectedLanguage = 'Português';

  final List<String> languages = ['Português', 'English', 'Español'];

  void logout() {
    Provider.of<AuthProvider>(context, listen: false).logout();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Configurações"),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Configuração de Tema
            SwitchListTile(
              title: Text("Tema Escuro"),
              value: isDarkTheme,
              onChanged: (value) {
                setState(() {
                  isDarkTheme = value;
                  // Aqui você pode integrar a lógica de troca de tema global
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(isDarkTheme
                        ? "Tema escuro ativado!"
                        : "Tema claro ativado!"),
                  ),
                );
              },
            ),

            SizedBox(height: 20),

            // Configuração de Idioma
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: "Idioma",
                border: OutlineInputBorder(),
              ),
              value: selectedLanguage,
              items: languages.map((language) {
                return DropdownMenuItem(
                  value: language,
                  child: Text(language),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedLanguage = value!;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Idioma alterado para $selectedLanguage")),
                  );
                });
              },
            ),

            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 50,
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.logout),
                      label: Text("Logout"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                      onPressed: logout,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}