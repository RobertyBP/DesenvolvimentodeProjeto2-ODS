import 'package:flutter/material.dart';
import 'package:ods/screens/user.dart';
import 'package:ods/screens/settings.dart';
import 'package:ods/services/auth_provider.dart';
import 'package:provider/provider.dart';
import 'login.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text("Home Page")),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                "Bem-vindo!",
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
            ListTile(
              title: Text(authProvider.isLoggedIn ? "User" : "Login"),
              leading: Icon(authProvider.isLoggedIn
                  ? Icons.person
                  : Icons.login),
              onTap: () {
                if (authProvider.isLoggedIn) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => User()),
                  );
                } else {
                
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => Login()),
                  );
                }
              },
            ),
            ListTile(
              title: Text("Configurações"),
              trailing: Icon(Icons.settings),
              onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => Settings()),
                  );
                
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          children: [
          Image.asset(
            'assets/images/arvre.png', // Caminho para o logo
            width: 250, // Ajusta a largura
            height: 250, // Ajusta a altura
          ),
          Text(
            "Bem-vindo à página principal!",
            style: TextStyle(fontSize: 24),
          ),
          SizedBox(
            height: 40,
            width: 40),
            Card(
              color: Colors.blue,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  "Card con noticias sobre o clima ou 'missão do game '",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      )
    );
  }
}