import 'package:flutter/material.dart';
import 'package:ods/screens/register.dart';
import 'package:ods/screens/home.dart';
import 'package:ods/services/auth_provider.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  
  String _email = '';
  String _senha = '';
  int flag = 0;
  AuthService authService = AuthService();
  void _loginC(){
    Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Register()),
        );
  }
  void _login() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      bool isUserRegistered = authService.verificarCadastro(_email);

      if (isUserRegistered) {
        bool isAuthenticated = authService.login(_email, _senha);
        if (isAuthenticated) {
          String? nome = authService.obterNome(_email);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Bem-vindo, ${nome ?? "Usuário"}!"),
          ));
          Provider.of<AuthProvider>(context, listen: false).login();

          Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Home(),
          ),
        );

        } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Senha incorreta."),
          ));
        }
      }
      
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Email",
                  icon: Icon(Icons.person)),
                validator: (value) => value!.contains("@") ? null : "Email inválido",
                onSaved: (value) => _email = value!,
              ),
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Senha",
                  icon: Icon(Icons.password)),
                obscureText: true,
                validator: (value) => value!.length >= 6 ? null : "Senha curta",
                onSaved: (value) => _senha = value!,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _login,
                child: Text("Login"),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _loginC,
                child: Text("Criar conta"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}