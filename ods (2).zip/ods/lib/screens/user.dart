import 'package:flutter/material.dart';

class User extends StatefulWidget {
  @override
  _UserState createState() => _UserState();
}

class _UserState extends State<User> {
  final _formKey = GlobalKey<FormState>();

  // Controladores e variáveis
  final TextEditingController _nomeController = TextEditingController();
  final TextEditingController _idadeController = TextEditingController();
  String _modoDeVida = 'Urbano';
  String _tipoDeTransporte = 'Carro';
  double _consumoEnergia = 0; // kWh
  double _consumoAgua = 0; // Litros

  // Lista de opções
  final List<String> _modosDeVida = ['Urbano', 'Rural'];
  final List<String> _tiposDeTransporte = [
    'Carro',
    'Moto',
    'Bicicleta',
    'Transporte Público'
  ];

  void _salvarConfiguracoes() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      // Aqui você pode salvar os dados no Firebase ou localmente.
      print("Nome: ${_nomeController.text}");
      print("Idade: ${_idadeController.text}");
      print("Modo de Vida: $_modoDeVida");
      print("Transporte: $_tipoDeTransporte");
      print("Consumo de Energia: $_consumoEnergia kWh");
      print("Consumo de Água: $_consumoAgua litros");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Configurações"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nomeController,
                decoration: InputDecoration(
                  labelText: 'Nome de Usuario',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Informe o nome de Usuario' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _idadeController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Idade',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Informe a idade';
                  }
                  final idade = int.tryParse(value);
                  if (idade == null || idade <= 0) {
                    return 'Idade inválida';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Dropdown Modo de Vida
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: 'Modo de Vida',
                  border: OutlineInputBorder(),
                ),
                value: _modoDeVida,
                items: _modosDeVida
                    .map((modo) => DropdownMenuItem(
                          value: modo,
                          child: Text(modo),
                        ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _modoDeVida = value!;
                  });
                },
              ),
              SizedBox(height: 16),

              // Dropdown Tipo de Transporte
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: 'Tipo de Transporte',
                  border: OutlineInputBorder(),
                ),
                value: _tipoDeTransporte,
                items: _tiposDeTransporte
                    .map((transporte) => DropdownMenuItem(
                          value: transporte,
                          child: Text(transporte),
                        ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _tipoDeTransporte = value!;
                  });
                },
              ),
              SizedBox(height: 16),

              // Slider Consumo de Energia
              Text("Consumo Médio de Energia (kWh)"),
              Slider(
                value: _consumoEnergia,
                min: 0,
                max: 1000,
                divisions: 20,
                label: "${_consumoEnergia.toStringAsFixed(0)} kWh",
                onChanged: (value) {
                  setState(() {
                    _consumoEnergia = value;
                  });
                },
              ),
              SizedBox(height: 16),

              // Slider Consumo de Água
              Text("Consumo de Água Mensal (litros)"),
              Slider(
                value: _consumoAgua,
                min: 0,
                max: 50000,
                divisions: 20,
                label: "${_consumoAgua.toStringAsFixed(0)} litros",
                onChanged: (value) {
                  setState(() {
                    _consumoAgua = value;
                  });
                },
              ),
              SizedBox(height: 20),

              // Botão Salvar
              ElevatedButton(
                onPressed: _salvarConfiguracoes,
                child: Text("Salvar Configurações"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}