import 'package:flutter/material.dart';


class Home extends StatefulWidget {
  final String email, nome;
  Home({required this.email, required this.nome});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
  return Scaffold(
      appBar: AppBar(title: Text("Home Page")),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Nome: nome", style: TextStyle(color: Colors.white, fontSize: 18)),
                  Text("Email: email", style: TextStyle(color: Colors.white, fontSize: 18)),
                ],
              ),
            ),
            ListTile(
              title: Text("Opção 1"),
              onTap: () {},
            ),
            ListTile(
              title: Text("Opção 2"),
              onTap: () {},
            ),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              "Bem-vindo à página principal!",
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            
          ],
        ),
      ),
    );
  }
}
